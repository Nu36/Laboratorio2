package org.mps.deque;

public class DoubleEndedQueueException extends RuntimeException {
    public DoubleEndedQueueException(String message) {
        super(message);
    }
}
