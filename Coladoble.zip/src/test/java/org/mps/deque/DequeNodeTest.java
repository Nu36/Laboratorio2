package org.mps.deque;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.Deque;

import static org.junit.jupiter.api.Assertions.*;
@Nested
@DisplayName("DequeNode")
class DequeNodeTest {

    DequeNode<Integer> node;

    @BeforeEach
    void init() { node = new DequeNode<>(4, null, null); }

    @AfterEach
    void shutDown(){node = null;}

    @Test
    public void ElDequeNodeSeCreaCorrectamente() {
        int obtainedValue = node.getItem();
        int expectedValue = 4;

        assertEquals(expectedValue, obtainedValue);
    }

    @Test
    void ElNodoPrevioEsNull() {
        Dequenode<> expec
    }
}