package org.mps.deque;

import static org.junit.jupiter.api.Assertions.*;

class DoublyLinkedListDequeTest {

}